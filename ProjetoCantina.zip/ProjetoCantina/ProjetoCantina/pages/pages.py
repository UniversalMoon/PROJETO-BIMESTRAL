from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout,
    QScrollArea,
)
from config import APP, C


class Sobre(QWidget):
    def __init__(self):
        super().__init__()

        # scroll caso a tela seja pequena
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")

        container = QWidget()
        container.setStyleSheet("background: transparent;")
        root = QVBoxLayout(container)
        root.setContentsMargins(40, 32, 40, 32)
        root.setSpacing(20)

        # ---------- cabeçalho ----------
        header = QFrame()
        header.setObjectName("Card")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(32, 28, 32, 28)
        hl.setSpacing(6)

        titulo = QLabel(APP)
        titulo.setStyleSheet(f"""
            font-size: 28px; font-weight: 800; color: {C.PRIMARY};
            letter-spacing: -0.5px;
        """)
        hl.addWidget(titulo)

        sub = QLabel("Sistema de autoatendimento para cantina escolar")
        sub.setStyleSheet(f"font-size: 14px; color: {C.MUTED};")
        hl.addWidget(sub)

        linha = QFrame()
        linha.setFrameShape(QFrame.HLine)
        linha.setStyleSheet(f"color: {C.BORDER}; margin: 8px 0;")
        hl.addWidget(linha)

        desc = QLabel(
            "Projeto desenvolvido para a disciplina de Programação, com o objetivo "
            "de reduzir filas e organizar o atendimento da cantina do IFSP – Campus "
            "Presidente Epitácio (CJO). O sistema permite que os alunos façam pedidos "
            "por um totem, enquanto a equipe da cantina gerencia a fila, os pagamentos "
            "e o financeiro em tempo real."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"font-size: 13px; color: {C.TEXT}; line-height: 1.5;")
        hl.addWidget(desc)
        root.addWidget(header)

        # ---------- integrantes ----------
        titulo_2 = QLabel("Desenvolvido por")
        titulo_2.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {C.TEXT};")
        root.addWidget(titulo_2)

        grid = QGridLayout()
        grid.setSpacing(16)

        integrantes = [
            ("Leandro Pellizzola", "Desenvolvedor"),
            ("Davi Ribeiro", "Desenvolvedor"),
        ]

        for i, (nome, funcao) in enumerate(integrantes):
            card = self._card_integrante(nome, funcao)
            grid.addWidget(card, 0, i)

        root.addLayout(grid)

        # ---------- tecnologias ----------
        titulo_3 = QLabel("Tecnologias utilizadas")
        titulo_3.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {C.TEXT};")
        root.addWidget(titulo_3)

        tech_box = QFrame()
        tech_box.setObjectName("Card")
        tl = QVBoxLayout(tech_box)
        tl.setContentsMargins(24, 20, 24, 20)
        tl.setSpacing(8)

        techs = [
            ("Python 3", "Linguagem principal do projeto"),
            ("PySide6 (Qt)", "Interface gráfica"),
            ("SQLite", "Banco de dados local"),
            ("Arquitetura MVC", "Organização do código"),
        ]
        for nome, desc in techs:
            linha_t = QHBoxLayout()
            ponto = QLabel("●")
            ponto.setStyleSheet(f"color: {C.PRIMARY}; font-size: 12px;")
            linha_t.addWidget(ponto)

            n = QLabel(f"<b>{nome}</b>")
            n.setStyleSheet(f"font-size: 13px; color: {C.TEXT};")
            linha_t.addWidget(n)

            d = QLabel(f"— {desc}")
            d.setStyleSheet(f"font-size: 12px; color: {C.MUTED};")
            linha_t.addWidget(d)
            linha_t.addStretch()
            tl.addLayout(linha_t)

        root.addWidget(tech_box)

        # ---------- funcionalidades ----------
        titulo_4 = QLabel("Principais funcionalidades")
        titulo_4.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {C.TEXT};")
        root.addWidget(titulo_4)

        func_box = QFrame()
        func_box.setObjectName("Card")
        fl = QVBoxLayout(func_box)
        fl.setContentsMargins(24, 20, 24, 20)
        fl.setSpacing(8)

        funcs = [
            "Totem de autoatendimento para pedidos dos alunos",
            "Fila de pedidos em quadro kanban (aguardando / preparando / pronto)",
            "Controle de estoque de produtos com alerta de últimas unidades",
            "Cadastro de produtos por categoria",
            "Registro de despesas e acompanhamento financeiro",
            "Relatórios de faturamento, lucro e produtos mais vendidos",
            "Cancelamento de pedidos com devolução automática de estoque",
        ]
        for f in funcs:
            linha_f = QHBoxLayout()
            check = QLabel("✓")
            check.setStyleSheet(f"color: {C.SUCCESS}; font-weight: 700;")
            linha_f.addWidget(check)

            txt = QLabel(f)
            txt.setStyleSheet(f"font-size: 13px; color: {C.TEXT};")
            txt.setWordWrap(True)
            linha_f.addWidget(txt, 1)
            fl.addLayout(linha_f)

        root.addWidget(func_box)

        # ---------- rodapé ----------
        root.addStretch()

        rodape = QLabel(
            f"{APP} · 2026 · Trabalho acadêmico — IFSP CJO"
        )
        rodape.setAlignment(Qt.AlignCenter)
        rodape.setStyleSheet(f"color: {C.MUTED}; font-size: 11px; margin-top: 20px;")
        root.addWidget(rodape)

        scroll.setWidget(container)

        wrapper = QVBoxLayout(self)
        wrapper.setContentsMargins(0, 0, 0, 0)
        wrapper.addWidget(scroll)

    def _card_integrante(self, nome, funcao):
        card = QFrame()
        card.setObjectName("Card")
        card.setMinimumHeight(140)

        l = QVBoxLayout(card)
        l.setContentsMargins(24, 22, 24, 22)
        l.setSpacing(8)
        l.setAlignment(Qt.AlignCenter)

        # "avatar" com iniciais
        iniciais = "".join(p[0].upper() for p in nome.split()[:2])
        avatar = QLabel(iniciais)
        avatar.setFixedSize(60, 60)
        avatar.setAlignment(Qt.AlignCenter)
        avatar.setStyleSheet(f"""
            background: {C.PRIMARY_SOFT};
            color: {C.PRIMARY};
            border-radius: 30px;
            font-size: 22px;
            font-weight: 800;
        """)
        l.addWidget(avatar, alignment=Qt.AlignCenter)

        n = QLabel(nome)
        n.setAlignment(Qt.AlignCenter)
        n.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {C.TEXT};")
        l.addWidget(n)

        f = QLabel(funcao)
        f.setAlignment(Qt.AlignCenter)
        f.setStyleSheet(f"font-size: 12px; color: {C.MUTED};")
        l.addWidget(f)

        return card