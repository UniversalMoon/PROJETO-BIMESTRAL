from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QScrollArea, QGridLayout, QComboBox, QMessageBox,
    QStackedWidget, QButtonGroup,
)
from config import CATEGORIAS, PAGAMENTOS, C
from database import listar_produtos, novo_pedido
from models import Carrinho
from ui import moeda, ProdutoCard, ItemCarrinho


class Totem(QWidget):
    feito = Signal()

    def __init__(self):
        super().__init__()
        self.carrinho = Carrinho()
        self.categoria = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        self.stack = QStackedWidget()
        root.addWidget(self.stack)
        self.stack.addWidget(self._tela_pedido())
        self.stack.addWidget(self._tela_ok())

    def _tela_pedido(self):
        w = QWidget()
        root = QHBoxLayout(w)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        esq = QWidget()
        esq.setStyleSheet(f"background: {C.BG};")
        el = QVBoxLayout(esq)
        el.setContentsMargins(28, 22, 20, 22)
        el.setSpacing(14)

        t = QLabel("Faça seu pedido")
        t.setProperty("h1", "true")
        el.addWidget(t)

        self.busca = QLineEdit()
        self.busca.setPlaceholderText("Buscar produto...")
        self.busca.setMinimumHeight(42)
        self.busca.textChanged.connect(self._carregar)
        el.addWidget(self.busca)

        chips = QHBoxLayout()
        chips.setSpacing(6)
        self.grupo = QButtonGroup(self)
        self.grupo.setExclusive(True)
        chips.addWidget(self._chip("Todos", None, True))
        for cat in CATEGORIAS:
            chips.addWidget(self._chip(cat, cat))
        chips.addStretch()
        el.addLayout(chips)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        self.grade_w = QWidget()
        self.grade_w.setStyleSheet("background: transparent;")
        self.grade = QGridLayout(self.grade_w)
        self.grade.setSpacing(14)
        self.grade.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.grade_w)
        el.addWidget(self.scroll, 1)

        # carrinho
        dir_ = QFrame()
        dir_.setFixedWidth(370)
        dir_.setStyleSheet(f"background: {C.CARD}; border-left: 1px solid {C.BORDER};")
        dl = QVBoxLayout(dir_)
        dl.setContentsMargins(20, 22, 20, 22)
        dl.setSpacing(12)

        titulo = QLabel("Carrinho")
        titulo.setProperty("h2", "true")
        dl.addWidget(titulo)

        self.scroll_itens = QScrollArea()
        self.scroll_itens.setWidgetResizable(True)
        self.scroll_itens.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        self.itens_w = QWidget()
        self.itens_w.setStyleSheet("background: transparent;")
        self.itens_l = QVBoxLayout(self.itens_w)
        self.itens_l.setSpacing(8)
        self.itens_l.setAlignment(Qt.AlignTop)
        self.scroll_itens.setWidget(self.itens_w)
        dl.addWidget(self.scroll_itens, 1)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"color: {C.BORDER};")
        dl.addWidget(sep)

        self.lbl_total = QLabel("R$ 0,00")
        self.lbl_total.setStyleSheet(f"font-size: 22px; font-weight: 700; color: {C.PRIMARY};")
        dl.addWidget(self.lbl_total)

        dl.addWidget(QLabel("Seu nome"))
        self.inp_nome = QLineEdit()
        self.inp_nome.setPlaceholderText("Digite seu nome")
        self.inp_nome.setMinimumHeight(40)
        dl.addWidget(self.inp_nome)

        dl.addWidget(QLabel("Pagamento"))
        self.cb_forma = QComboBox()
        self.cb_forma.setMinimumHeight(40)
        for f in PAGAMENTOS:
            self.cb_forma.addItem(f)
        dl.addWidget(self.cb_forma)

        self.btn_confirmar = QPushButton("Confirmar pedido")
        self.btn_confirmar.setMinimumHeight(48)
        self.btn_confirmar.setEnabled(False)
        self.btn_confirmar.setStyleSheet(f"""
            QPushButton {{
                background: {C.SUCCESS}; color: white; border: none;
                border-radius: 8px; font-size: 14px; font-weight: 700;
            }}
            QPushButton:hover {{ background: #15803d; }}
            QPushButton:disabled {{ background: #cbd5e1; color: #94a3b8; }}
        """)
        self.btn_confirmar.clicked.connect(self._confirmar)
        dl.addWidget(self.btn_confirmar)

        root.addWidget(esq, 1)
        root.addWidget(dir_)

        self._carregar()
        self._render()
        return w

    def _chip(self, texto, cat, checked=False):
        b = QPushButton(texto)
        b.setCheckable(True)
        b.setChecked(checked)
        b.setCursor(Qt.PointingHandCursor)
        b.setMinimumHeight(32)
        b.setStyleSheet(f"""
            QPushButton {{
                background: {C.CARD}; color: {C.MUTED};
                border: 1px solid {C.BORDER}; border-radius: 16px;
                padding: 4px 16px; font-size: 12px;
            }}
            QPushButton:hover {{ border-color: {C.PRIMARY}; color: {C.PRIMARY}; }}
            QPushButton:checked {{
                background: {C.PRIMARY}; color: white; border-color: {C.PRIMARY};
            }}
        """)
        b.clicked.connect(lambda: self._set_cat(cat))
        self.grupo.addButton(b)
        return b

    def _set_cat(self, cat):
        self.categoria = cat
        self._carregar()

    def _carregar(self):
        while self.grade.count():
            it = self.grade.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

        lista = listar_produtos(self.busca.text().strip(), self.categoria, disponiveis=True)
        for i, p in enumerate(lista):
            c = ProdutoCard(p)
            c.clicado.connect(self._add)
            self.grade.addWidget(c, i // 3, i % 3)

        if not lista:
            v = QLabel("Nenhum produto encontrado.")
            v.setStyleSheet(f"color: {C.MUTED}; padding: 40px;")
            v.setAlignment(Qt.AlignCenter)
            self.grade.addWidget(v, 0, 0, 1, 3)

    def _add(self, produto):
        self.carrinho.adicionar(produto)
        self._render()

    def _render(self):
        while self.itens_l.count():
            it = self.itens_l.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

        if self.carrinho.vazio():
            v = QLabel("Nenhum item ainda")
            v.setStyleSheet(f"color: {C.MUTED}; padding: 20px;")
            v.setAlignment(Qt.AlignCenter)
            self.itens_l.addWidget(v)
        else:
            for pid, item in list(self.carrinho.itens.items()):
                w = ItemCarrinho(item["produto"], item["qtd"])
                w.mais.connect(lambda p: (self.carrinho.aumentar(p), self._render()))
                w.menos.connect(lambda p: (self.carrinho.diminuir(p), self._render()))
                w.remover.connect(lambda p: (self.carrinho.remover(p), self._render()))
                self.itens_l.addWidget(w)

        self.lbl_total.setText(moeda(self.carrinho.total()))
        self.btn_confirmar.setEnabled(not self.carrinho.vazio())

    def _confirmar(self):
        nome = self.inp_nome.text().strip()
        if not nome:
            QMessageBox.warning(self, "Aviso", "Digite seu nome.")
            self.inp_nome.setFocus()
            return

        forma = self.cb_forma.currentText()
        ok, res = novo_pedido(self.carrinho.itens, nome, forma)
        if not ok:
            QMessageBox.critical(self, "Erro", res)
            return

        self.lbl_codigo.setText(res["codigo"])
        self.lbl_info.setText(f"{nome} — {moeda(res['total'])} em {forma}")

        self.carrinho.limpar()
        self.inp_nome.clear()
        self.cb_forma.setCurrentIndex(0)
        self._render()
        self.feito.emit()

        self.stack.setCurrentIndex(1)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(lambda: self.stack.setCurrentIndex(0))
        self._timer.start(12000)

    def _tela_ok(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.setAlignment(Qt.AlignCenter)
        l.setSpacing(10)

        t = QLabel("Pedido confirmado")
        t.setStyleSheet(f"font-size: 18px; color: {C.MUTED};")
        t.setAlignment(Qt.AlignCenter)
        l.addWidget(t)

        self.lbl_codigo = QLabel()
        self.lbl_codigo.setStyleSheet(f"font-size: 96px; font-weight: 800; color: {C.SUCCESS};")
        self.lbl_codigo.setAlignment(Qt.AlignCenter)
        l.addWidget(self.lbl_codigo)

        self.lbl_info = QLabel()
        self.lbl_info.setStyleSheet(f"font-size: 15px; color: {C.TEXT};")
        self.lbl_info.setAlignment(Qt.AlignCenter)
        l.addWidget(self.lbl_info)

        aviso = QLabel("Aguarde ser chamado no balcão.")
        aviso.setStyleSheet(f"color: {C.MUTED}; font-size: 13px; margin-top: 10px;")
        aviso.setAlignment(Qt.AlignCenter)
        l.addWidget(aviso)

        b = QPushButton("Novo pedido")
        b.setMinimumHeight(46)
        b.setMinimumWidth(200)
        b.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        l.addWidget(b, alignment=Qt.AlignCenter)
        return w