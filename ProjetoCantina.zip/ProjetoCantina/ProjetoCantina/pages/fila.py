from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QFrame, QPushButton, QMessageBox, QTabWidget, QTableWidgetItem,
)
from config import C
from database import listar_pedidos, obter_pedido, mudar_status, cancelar_pedido
from ui import PedidoCard, tabela, moeda, data_br


class Coluna(QFrame):
    def __init__(self, titulo, cor, on_avancar, on_cancelar):
        super().__init__()
        self.titulo = titulo
        self.on_avancar = on_avancar
        self.on_cancelar = on_cancelar
        self.cor = cor
        self.setObjectName("Card")

        l = QVBoxLayout(self)
        l.setContentsMargins(12, 12, 12, 12)
        l.setSpacing(8)

        head = QHBoxLayout()
        dot = QLabel("●")
        dot.setStyleSheet(f"color: {cor}; font-size: 16px;")
        head.addWidget(dot)
        self.lbl = QLabel(titulo)
        self.lbl.setStyleSheet("font-size: 14px; font-weight: 700;")
        head.addWidget(self.lbl)
        head.addStretch()
        l.addLayout(head)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        self.cl = QVBoxLayout(container)
        self.cl.setSpacing(8)
        self.cl.setAlignment(Qt.AlignTop)
        scroll.setWidget(container)
        l.addWidget(scroll, 1)

    def set_pedidos(self, lista):
        while self.cl.count():
            it = self.cl.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

        self.lbl.setText(f"{self.titulo}  ({len(lista)})")

        if not lista:
            v = QLabel("Nenhum")
            v.setStyleSheet(f"color: {C.MUTED}; padding: 20px;")
            v.setAlignment(Qt.AlignCenter)
            self.cl.addWidget(v)
            return

        for p in lista:
            _, itens = obter_pedido(p["id"])
            c = PedidoCard(p, itens, self.cor)
            c.acao.connect(self.on_avancar)
            c.cancelar.connect(self.on_cancelar)
            self.cl.addWidget(c)


class Fila(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 22)
        root.setSpacing(14)

        top = QHBoxLayout()
        t = QLabel("Fila de pedidos")
        t.setProperty("h1", "true")
        top.addWidget(t)
        top.addStretch()
        b = QPushButton("Atualizar")
        b.setProperty("variant", "secondary")
        b.clicked.connect(self.refresh)
        top.addWidget(b)
        root.addLayout(top)

        tabs = QTabWidget()
        tabs.addTab(self._kanban(), "Em andamento")
        tabs.addTab(self._historico(), "Histórico")
        tabs.currentChanged.connect(self._tab_mudou)
        root.addWidget(tabs, 1)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._atualizar_kanban)
        self.timer.start(6000)

        self.refresh()

    def _kanban(self):
        w = QWidget()
        l = QHBoxLayout(w)
        l.setSpacing(12)

        self.col_ag = Coluna("Aguardando", C.WARNING, self._avancar, self._cancelar_kanban)
        self.col_pr = Coluna("Preparando", C.INFO, self._avancar, self._cancelar_kanban)
        self.col_pt = Coluna("Pronto", C.SUCCESS, self._avancar, self._cancelar_kanban)
        for c in (self.col_ag, self.col_pr, self.col_pt):
            l.addWidget(c, 1)
        return w

    def _historico(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.tab = tabela(["Código", "Cliente", "Data", "Forma", "Status", "Total"], 1)
        self.tab.doubleClicked.connect(self._cancelar)
        l.addWidget(self.tab)
        return w

    def _avancar(self, pid, novo):
        mudar_status(pid, novo)
        self._atualizar_kanban()

    def _cancelar_kanban(self, pid):
        p, _ = obter_pedido(pid)
        if not p:
            return
        if QMessageBox.question(
            self, "Cancelar pedido",
            f"Cancelar o pedido {p['codigo']} de {p['cliente_nome']}?",
        ) != QMessageBox.Yes:
            return
        ok, msg = cancelar_pedido(pid)
        if ok:
            self._atualizar_kanban()
            self._carregar_historico()

    def _atualizar_kanban(self):
        self.col_ag.set_pedidos(listar_pedidos("aguardando"))
        self.col_pr.set_pedidos(listar_pedidos("preparando"))
        self.col_pt.set_pedidos(listar_pedidos("pronto"))

    def refresh(self):
        self._atualizar_kanban()
        self._carregar_historico()

    def _carregar_historico(self):
        lista = listar_pedidos()
        self.tab.setRowCount(len(lista))
        self._ids = []
        for i, p in enumerate(lista):
            self.tab.setItem(i, 0, QTableWidgetItem(p["codigo"]))
            self.tab.setItem(i, 1, QTableWidgetItem(p["cliente_nome"]))
            self.tab.setItem(i, 2, QTableWidgetItem(data_br(p["criado_em"])))
            self.tab.setItem(i, 3, QTableWidgetItem(p["forma_pagamento"]))
            self.tab.setItem(i, 4, QTableWidgetItem(p["status"].capitalize()))
            self.tab.setItem(i, 5, QTableWidgetItem(moeda(p["total"])))
            self._ids.append(p["id"])

    def _cancelar(self, idx):
        if idx.row() >= len(self._ids):
            return
        pid = self._ids[idx.row()]
        p, _ = obter_pedido(pid)
        if p["status"] == "cancelado":
            QMessageBox.information(self, "Pedido", "Já está cancelado.")
            return
        if QMessageBox.question(
            self, "Cancelar",
            f"Cancelar o pedido {p['codigo']} de {p['cliente_nome']}?",
        ) != QMessageBox.Yes:
            return
        ok, msg = cancelar_pedido(pid)
        if ok:
            self.refresh()

    def _tab_mudou(self, i):
        if i == 1:
            self._carregar_historico()