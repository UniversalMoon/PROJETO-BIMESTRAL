from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout,
    QDateEdit, QPushButton, QMessageBox, QTableWidgetItem, QDialog,
    QFormLayout, QLineEdit, QDoubleSpinBox, QDialogButtonBox,
)
from config import C
from database import (
    resumo_dia, top_produtos, por_forma, total_despesas,
    listar_despesas, criar_despesa, excluir_despesa,
)
from ui import StatCard, tabela, moeda


class NovaDespesa(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nova despesa")
        self.setMinimumWidth(380)

        l = QVBoxLayout(self)
        f = QFormLayout()
        f.setSpacing(10)

        self.desc = QLineEdit()
        f.addRow("Descrição", self.desc)

        self.valor = QDoubleSpinBox()
        self.valor.setRange(0, 999999)
        self.valor.setDecimals(2)
        self.valor.setPrefix("R$ ")
        f.addRow("Valor", self.valor)

        self.data = QDateEdit()
        self.data.setCalendarPopup(True)
        self.data.setDate(QDate.currentDate())
        f.addRow("Data", self.data)
        l.addLayout(f)

        b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        b.button(QDialogButtonBox.Ok).setText("Salvar")
        b.button(QDialogButtonBox.Cancel).setText("Cancelar")
        b.button(QDialogButtonBox.Cancel).setProperty("variant", "secondary")
        b.accepted.connect(self._salvar)
        b.rejected.connect(self.reject)
        l.addWidget(b)

    def _salvar(self):
        if not self.desc.text().strip():
            QMessageBox.warning(self, "Aviso", "Informe a descrição.")
            return
        if self.valor.value() <= 0:
            QMessageBox.warning(self, "Aviso", "Valor inválido.")
            return
        criar_despesa(
            self.desc.text().strip(),
            self.valor.value(),
            self.data.date().toString("yyyy-MM-dd"),
        )
        self.accept()


class Financeiro(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 22)
        root.setSpacing(14)

        t = QLabel("Financeiro")
        t.setProperty("h1", "true")
        root.addWidget(t)

        # filtros
        filtro = QHBoxLayout()
        filtro.addWidget(QLabel("De"))
        self.dt_ini = QDateEdit()
        self.dt_ini.setCalendarPopup(True)
        self.dt_ini.setDate(QDate.currentDate().addDays(-7))
        filtro.addWidget(self.dt_ini)

        filtro.addWidget(QLabel("até"))
        self.dt_fim = QDateEdit()
        self.dt_fim.setCalendarPopup(True)
        self.dt_fim.setDate(QDate.currentDate())
        filtro.addWidget(self.dt_fim)

        b = QPushButton("Aplicar")
        b.clicked.connect(self._atualizar)
        filtro.addWidget(b)
        filtro.addStretch()

        bd = QPushButton("Nova despesa")
        bd.setProperty("variant", "secondary")
        bd.clicked.connect(self._nova_despesa)
        filtro.addWidget(bd)
        root.addLayout(filtro)

        # cards dia
        self.grid_hoje = QGridLayout()
        self.grid_hoje.setSpacing(12)
        root.addLayout(self.grid_hoje)

        # cards período
        self.grid_per = QGridLayout()
        self.grid_per.setSpacing(12)
        root.addLayout(self.grid_per)

        # listas
        linha = QHBoxLayout()
        linha.setSpacing(12)

        b1 = QFrame()
        b1.setObjectName("Card")
        l1 = QVBoxLayout(b1)
        l1.setContentsMargins(18, 16, 18, 16)
        l1.setSpacing(10)
        l1.addWidget(self._titulo("Receitas por forma (período)"))
        self.tab_rec = tabela(["Forma", "Qtd", "Total"], 0)
        self.tab_rec.setMinimumHeight(180)
        l1.addWidget(self.tab_rec)
        linha.addWidget(b1, 1)

        b2 = QFrame()
        b2.setObjectName("Card")
        l2 = QVBoxLayout(b2)
        l2.setContentsMargins(18, 16, 18, 16)
        l2.setSpacing(10)
        l2.addWidget(self._titulo("Top produtos"))
        self.tab_top = tabela(["Produto", "Qtd", "Total"], 0)
        self.tab_top.setMinimumHeight(180)
        l2.addWidget(self.tab_top)
        linha.addWidget(b2, 1)

        root.addLayout(linha)

        # despesas
        b3 = QFrame()
        b3.setObjectName("Card")
        l3 = QVBoxLayout(b3)
        l3.setContentsMargins(18, 16, 18, 16)
        l3.setSpacing(10)

        head = QHBoxLayout()
        head.addWidget(self._titulo("Despesas do período"))
        head.addStretch()
        bdel = QPushButton("Excluir selecionada")
        bdel.setProperty("variant", "danger")
        bdel.clicked.connect(self._excluir_despesa)
        head.addWidget(bdel)
        l3.addLayout(head)

        self.tab_desp = tabela(["Data", "Descrição", "Valor"], 1)
        self.tab_desp.setMinimumHeight(160)
        l3.addWidget(self.tab_desp)
        root.addWidget(b3)

        self._atualizar()

    def _titulo(self, txt):
        l = QLabel(txt)
        l.setProperty("h2", "true")
        return l

    def _limpar(self, layout):
        while layout.count():
            it = layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def _nova_despesa(self):
        if NovaDespesa(self).exec():
            self._atualizar()

    def _excluir_despesa(self):
        row = self.tab_desp.currentRow()
        if row < 0 or row >= len(self._desp_ids):
            QMessageBox.information(self, "Aviso", "Selecione uma despesa.")
            return
        if QMessageBox.question(self, "Confirmar", "Excluir esta despesa?") != QMessageBox.Yes:
            return
        excluir_despesa(self._desp_ids[row])
        self._atualizar()

    def _atualizar(self):
        ini = self.dt_ini.date().toString("yyyy-MM-dd")
        fim = self.dt_fim.date().toString("yyyy-MM-dd")

        self._limpar(self.grid_hoje)
        r = resumo_dia()
        self.grid_hoje.addWidget(StatCard("Pedidos hoje", r["qtd"]), 0, 0)
        self.grid_hoje.addWidget(
            StatCard("Faturamento hoje", moeda(r["faturamento"]), C.SUCCESS), 0, 1)
        self.grid_hoje.addWidget(
            StatCard("Despesas hoje", moeda(r["despesas"]), C.DANGER), 0, 2)
        self.grid_hoje.addWidget(
            StatCard("Lucro hoje", moeda(r["lucro"]),
                     C.SUCCESS if r["lucro"] >= 0 else C.DANGER), 0, 3)

        self._limpar(self.grid_per)
        rec = por_forma(ini, fim)
        tot_rec = sum(x["total"] or 0 for x in rec)
        tot_desp = total_despesas(ini, fim)
        lucro = tot_rec - tot_desp
        margem = (lucro / tot_rec * 100) if tot_rec else 0

        self.grid_per.addWidget(
            StatCard("Receitas período", moeda(tot_rec), C.SUCCESS), 0, 0)
        self.grid_per.addWidget(
            StatCard("Despesas período", moeda(tot_desp), C.DANGER), 0, 1)
        self.grid_per.addWidget(
            StatCard("Lucro período", moeda(lucro),
                     C.SUCCESS if lucro >= 0 else C.DANGER), 0, 2)
        self.grid_per.addWidget(StatCard("Margem", f"{margem:.1f}%", C.INFO), 0, 3)

        self.tab_rec.setRowCount(len(rec))
        for i, x in enumerate(rec):
            self.tab_rec.setItem(i, 0, QTableWidgetItem(x["forma_pagamento"]))
            self.tab_rec.setItem(i, 1, QTableWidgetItem(str(x["qtd"] or 0)))
            self.tab_rec.setItem(i, 2, QTableWidgetItem(moeda(x["total"] or 0)))

        top = top_produtos(8)
        self.tab_top.setRowCount(len(top))
        for i, x in enumerate(top):
            self.tab_top.setItem(i, 0, QTableWidgetItem(x["nome"]))
            self.tab_top.setItem(i, 1, QTableWidgetItem(str(x["qtd"] or 0)))
            self.tab_top.setItem(i, 2, QTableWidgetItem(moeda(x["total"] or 0)))

        desp = listar_despesas(ini, fim)
        self.tab_desp.setRowCount(len(desp))
        self._desp_ids = []
        for i, d in enumerate(desp):
            self.tab_desp.setItem(i, 0, QTableWidgetItem(d["data"]))
            self.tab_desp.setItem(i, 1, QTableWidgetItem(d["descricao"]))
            self.tab_desp.setItem(i, 2, QTableWidgetItem(moeda(d["valor"])))
            self._desp_ids.append(d["id"])