from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QComboBox, QMessageBox, QTableWidgetItem, QDialog, QFormLayout,
    QSpinBox, QDoubleSpinBox, QCheckBox, QDialogButtonBox,
)
from config import CATEGORIAS
from database import (
    listar_produtos, obter_produto, salvar_produto, excluir_produto,
)
from ui import tabela, moeda


class EditarProduto(QDialog):
    def __init__(self, parent=None, p=None):
        super().__init__(parent)
        self.p = p
        self.setWindowTitle("Editar produto" if p else "Novo produto")
        self.setMinimumWidth(400)

        l = QVBoxLayout(self)
        f = QFormLayout()
        f.setSpacing(10)

        self.nome = QLineEdit()
        f.addRow("Nome", self.nome)

        self.desc = QLineEdit()
        f.addRow("Descrição", self.desc)

        self.preco = QDoubleSpinBox()
        self.preco.setRange(0, 99999)
        self.preco.setDecimals(2)
        self.preco.setPrefix("R$ ")
        f.addRow("Preço", self.preco)

        self.cat = QComboBox()
        for c in CATEGORIAS:
            self.cat.addItem(c)
        f.addRow("Categoria", self.cat)

        self.est = QSpinBox()
        self.est.setRange(0, 999999)
        f.addRow("Estoque", self.est)

        self.ativo = QCheckBox("Ativo")
        self.ativo.setChecked(True)
        f.addRow("", self.ativo)
        l.addLayout(f)

        b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        b.button(QDialogButtonBox.Ok).setText("Salvar")
        b.button(QDialogButtonBox.Cancel).setText("Cancelar")
        b.button(QDialogButtonBox.Cancel).setProperty("variant", "secondary")
        b.accepted.connect(self._salvar)
        b.rejected.connect(self.reject)
        l.addWidget(b)

        if p:
            self.nome.setText(p["nome"])
            self.desc.setText(p["descricao"] or "")
            self.preco.setValue(p["preco"])
            self.est.setValue(p["estoque"])
            self.ativo.setChecked(bool(p["ativo"]))
            i = self.cat.findText(p["categoria"])
            if i >= 0:
                self.cat.setCurrentIndex(i)

    def _salvar(self):
        if not self.nome.text().strip():
            QMessageBox.warning(self, "Aviso", "Informe o nome.")
            return
        if self.preco.value() <= 0:
            QMessageBox.warning(self, "Aviso", "Preço deve ser maior que zero.")
            return

        pid = self.p["id"] if self.p else None
        ok, msg = salvar_produto(
            pid,
            self.nome.text().strip(),
            self.desc.text().strip(),
            self.preco.value(),
            self.cat.currentText(),
            self.est.value(),
            self.ativo.isChecked(),
        )
        if ok:
            self.accept()
        else:
            QMessageBox.critical(self, "Erro", msg)


class Produtos(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 22)
        root.setSpacing(14)

        t = QLabel("Produtos")
        t.setProperty("h1", "true")
        root.addWidget(t)

        top = QHBoxLayout()
        self.busca = QLineEdit()
        self.busca.setPlaceholderText("Buscar...")
        self.busca.textChanged.connect(self._refresh)
        top.addWidget(self.busca, 1)

        self.cb_cat = QComboBox()
        self.cb_cat.addItem("Todas categorias", None)
        for c in CATEGORIAS:
            self.cb_cat.addItem(c, c)
        self.cb_cat.currentIndexChanged.connect(self._refresh)
        top.addWidget(self.cb_cat)

        b = QPushButton("Novo produto")
        b.clicked.connect(self._novo)
        top.addWidget(b)
        root.addLayout(top)

        self.tab = tabela(["ID", "Nome", "Categoria", "Preço", "Estoque", "Status"], 1)
        self.tab.doubleClicked.connect(self._editar)
        root.addWidget(self.tab, 1)

        acoes = QHBoxLayout()
        acoes.addStretch()

        bed = QPushButton("Editar")
        bed.setProperty("variant", "secondary")
        bed.clicked.connect(self._editar)
        acoes.addWidget(bed)

        bdel = QPushButton("Excluir")
        bdel.setProperty("variant", "danger")
        bdel.clicked.connect(self._excluir)
        acoes.addWidget(bdel)

        root.addLayout(acoes)
        self._refresh()

    def _refresh(self):
        lista = listar_produtos(self.busca.text().strip(), self.cb_cat.currentData())
        self.tab.setRowCount(len(lista))
        self._ids = []
        for i, p in enumerate(lista):
            self.tab.setItem(i, 0, QTableWidgetItem(str(p["id"])))
            self.tab.setItem(i, 1, QTableWidgetItem(p["nome"]))
            self.tab.setItem(i, 2, QTableWidgetItem(p["categoria"]))
            self.tab.setItem(i, 3, QTableWidgetItem(moeda(p["preco"])))
            self.tab.setItem(i, 4, QTableWidgetItem(str(p["estoque"])))
            self.tab.setItem(i, 5, QTableWidgetItem("Ativo" if p["ativo"] else "Inativo"))
            self._ids.append(p["id"])

    def _novo(self):
        if EditarProduto(self).exec():
            self._refresh()

    def _editar(self):
        row = self.tab.currentRow()
        if row < 0 or row >= len(self._ids):
            return
        p = obter_produto(self._ids[row])
        if EditarProduto(self, p).exec():
            self._refresh()

    def _excluir(self):
        row = self.tab.currentRow()
        if row < 0 or row >= len(self._ids):
            QMessageBox.information(self, "Aviso", "Selecione um produto.")
            return
        if QMessageBox.question(
            self, "Confirmar", "Excluir este produto?"
        ) != QMessageBox.Yes:
            return
        ok, msg = excluir_produto(self._ids[row])
        if ok:
            self._refresh()
        else:
            QMessageBox.critical(self, "Erro", msg)