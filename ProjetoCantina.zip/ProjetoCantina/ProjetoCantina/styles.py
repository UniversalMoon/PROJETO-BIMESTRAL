from config import C

QSS = f"""
* {{ font-family: 'Segoe UI', 'Inter', Arial; color: {C.TEXT}; font-size: 13px; }}
QMainWindow, QDialog {{ background: {C.BG}; }}

/* ---------- Sidebar ---------- */
QFrame#Sidebar {{ background: {C.SIDEBAR}; border: none; }}
QLabel#Logo {{ color: white; font-size: 18px; font-weight: 700; padding: 26px 22px 2px 22px; }}
QLabel#LogoSub {{ color: {C.SIDEBAR_TEXT}; font-size: 11px; padding: 0 22px 24px 22px; }}
QPushButton#Nav {{
    background: transparent; color: {C.SIDEBAR_TEXT};
    text-align: left; padding: 11px 22px; border: none;
    border-radius: 8px; font-size: 13px; margin: 1px 10px;
}}
QPushButton#Nav:hover {{ background: {C.SIDEBAR_HOVER}; color: white; }}
QPushButton#Nav:checked {{ background: {C.PRIMARY}; color: white; font-weight: 600; }}
QFrame#UserBox {{ background: {C.SIDEBAR_HOVER}; border-radius: 10px; margin: 10px 12px; }}
QFrame#UserBox QLabel {{ color: #e2e8f0; }}
QFrame#UserBox QLabel#userRole {{ color: {C.SIDEBAR_TEXT}; font-size: 11px; }}

/* ---------- Cards ---------- */
QFrame#Card {{ background: {C.CARD}; border-radius: 12px; border: 1px solid {C.BORDER}; }}
QFrame#Card QFrame#Card {{ background: #fafbfc; }}

/* ---------- ProdutoCard (com banner) ---------- */
QFrame#ProdutoCard {{
    background: transparent;
    border: none;
}}
QFrame#ProdutoCard:hover {{ background: {C.PRIMARY_LIGHT}; border-radius: 12px; }}

/* ---------- Botões ---------- */
QPushButton {{
    background: {C.PRIMARY}; color: white; border: none; border-radius: 8px;
    padding: 9px 18px; font-size: 13px; font-weight: 500;
}}
QPushButton:hover {{ background: {C.PRIMARY_HOVER}; }}
QPushButton:disabled {{ background: #cbd5e1; color: #94a3b8; }}
QPushButton[variant="secondary"] {{
    background: {C.CARD}; color: {C.TEXT}; border: 1px solid {C.BORDER};
}}
QPushButton[variant="secondary"]:hover {{ background: {C.BG}; }}
QPushButton[variant="danger"] {{ background: {C.DANGER}; }}
QPushButton[variant="danger"]:hover {{ background: #b91c1c; }}
QPushButton[variant="success"] {{ background: {C.SUCCESS}; }}
QPushButton[variant="success"]:hover {{ background: #15803d; }}
QPushButton[variant="warning"] {{ background: {C.WARNING}; }}
QPushButton[variant="warning"]:hover {{ background: #b45309; }}

/* ---------- Inputs ---------- */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTextEdit {{
    background: {C.CARD}; border: 1px solid {C.BORDER};
    border-radius: 8px; padding: 8px 12px; font-size: 13px; min-height: 20px;
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus,
QDoubleSpinBox:focus, QDateEdit:focus, QTextEdit:focus {{
    border: 1px solid {C.PRIMARY};
}}
QComboBox::drop-down {{ border: none; width: 24px; }}

/* ---------- Tabelas ---------- */
QTableWidget {{
    background: {C.CARD}; border: 1px solid {C.BORDER}; border-radius: 12px;
    gridline-color: #f1f5f9; selection-background-color: {C.PRIMARY_LIGHT};
    selection-color: {C.PRIMARY}; font-size: 13px;
}}
QHeaderView::section {{
    background: {C.CARD}; color: {C.MUTED}; padding: 12px 10px;
    border: none; border-bottom: 1px solid {C.BORDER};
    font-weight: 600; font-size: 11px;
}}
QTableWidget::item {{ padding: 8px; }}
QTableWidget::item:selected {{ background: {C.PRIMARY_LIGHT}; color: {C.PRIMARY}; }}

/* ---------- Scroll ---------- */
QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: #cbd5e1; border-radius: 5px; min-height: 40px; }}
QScrollBar::handle:vertical:hover {{ background: #94a3b8; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

/* ---------- Tabs ---------- */
QTabWidget::pane {{ border: none; background: transparent; }}
QTabBar::tab {{
    background: transparent; padding: 8px 18px; margin-right: 4px;
    border-radius: 8px; color: {C.MUTED}; font-weight: 500;
}}
QTabBar::tab:selected {{ background: {C.PRIMARY_LIGHT}; color: {C.PRIMARY}; font-weight: 600; }}
QTabBar::tab:hover:!selected {{ background: {C.BG}; }}

QLabel[h1="true"] {{ font-size: 22px; font-weight: 700; }}
QLabel[h2="true"] {{ font-size: 15px; font-weight: 600; }}
QLabel[muted="true"] {{ color: {C.MUTED}; }}
"""