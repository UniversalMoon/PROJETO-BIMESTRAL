APP = "Cantina IFSP-CJO"
DB = "cantina.db"

CATEGORIAS = ["Salgados", "Bebidas", "Doces", "Lanches"]
PAGAMENTOS = ["Dinheiro", "Cartão", "Pix"]

EMOJI_CATEGORIA = {
    "Salgados": "🥟",
    "Bebidas": "🥤",
    "Doces": "🍬",
    "Lanches": "🍔",
}

EMOJI_PRODUTO = {
    # Doces
    "Doce": "🍬", "Paçoca": "🥜", "Bom Bom": "🍭", "Trento": "🍫",
    "Biscoito": "🍪", "Emília": "🍪", "Halls": "🍬", "Bolo": "🍰",
    "Suspiro": "🍥", "Pão de Mel": "🍯", "Copinho de Banana": "🍌",
    "Cocada": "🥥", "Doce em Massa de Batata Doce": "🍠",
    "Cajuzinho": "🥜", "Geladão": "🍧", "Cremosinho": "🍮",
    "Maria Bolacha": "🍪",
    # Bebidas
    "Café": "☕", "Guaraná 350ml": "🥤", "Fanta Uva 350ml": "🥤",
    "Fanta Laranja 350ml": "🥤", "Coca-Cola Zero 350ml": "🥤",
    "Coca-Cola 350ml": "🥤", "Suco Tropical 480ml": "🧃",
    "Suco Kmais 300ml": "🧃", "Refrigerante Caçula 200ml": "🥤",
    # Salgados
    "Cup Noodles": "🍜", "Croissant Apresuntado e Queijo": "🥐",
    "Risole de 4 Queijos": "🥟", "Risole de Carne": "🥟",
    "Croissant 3 Queijos": "🥐", "Hambúrguer com Cheddar": "🍔",
    "Enroladinho de Bauru": "🌯", "Pão de Batata com Calabresa": "🥖",
    "Pão de Batata de Frango": "🥖", "Esfiha de Carne": "🥙",
    "Coxinha": "🍗", "Pão de Queijo": "🧀", "Caldo": "🍲", "Espeto": "🍢",
}

COR_CATEGORIA = {
    "Salgados": "#FEF3C7",
    "Bebidas": "#DBEAFE",
    "Doces": "#FCE7F3",
    "Lanches": "#FFEDD5",
}


class C:
    PRIMARY = "#2563eb"
    PRIMARY_HOVER = "#1d4ed8"
    PRIMARY_LIGHT = "#eff6ff"
    PRIMARY_SOFT = "#dbeafe"

    SUCCESS = "#16a34a"
    SUCCESS_LIGHT = "#dcfce7"
    WARNING = "#d97706"
    WARNING_LIGHT = "#fef3c7"
    DANGER = "#dc2626"
    DANGER_LIGHT = "#fee2e2"
    INFO = "#0891b2"
    PURPLE = "#7c3aed"

    BG = "#f8fafc"
    CARD = "#ffffff"
    BORDER = "#e2e8f0"
    TEXT = "#0f172a"
    MUTED = "#64748b"

    SIDEBAR = "#0f172a"
    SIDEBAR_HOVER = "#1e293b"
    SIDEBAR_TEXT = "#94a3b8"