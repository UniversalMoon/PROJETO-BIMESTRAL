from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QStackedWidget, QButtonGroup, QMessageBox,
)
from config import APP
from pages.totem import Totem
from pages.fila import Fila
from pages.financeiro import Financeiro
from pages.produtos import Produtos
from pages.sobre import Sobre


class Janela(QMainWindow):
    saiu = Signal()

    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.setWindowTitle(f"{APP} — {usuario['nome']}")
        self.resize(1280, 800)
        self._montar()

    def _montar(self):
        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(220)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(0)

        logo = QLabel(APP)
        logo.setObjectName("Logo")
        sl.addWidget(logo)

        sub = QLabel("IFSP · CJO")
        sub.setObjectName("LogoSub")
        sl.addWidget(sub)

        self.grupo = QButtonGroup(self)
        self.grupo.setExclusive(True)
        self.stack = QStackedWidget()

        self._nav(sl, "Totem", lambda: Totem())
        self._nav(sl, "Fila", lambda: Fila())
        self._nav(sl, "Financeiro", lambda: Financeiro())
        self._nav(sl, "Produtos", lambda: Produtos())
        self._nav(sl, "Sobre", lambda: Sobre())

        sl.addStretch()

        box = QFrame()
        box.setObjectName("UserBox")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(14, 10, 14, 10)
        bl.setSpacing(2)

        n = QLabel(self.usuario["nome"])
        n.setStyleSheet("font-weight: 600;")
        bl.addWidget(n)

        role = "Administrador" if self.usuario["username"] == "admin" else "Operador"
        r = QLabel(role)
        r.setObjectName("userRole")
        bl.addWidget(r)
        sl.addWidget(box)

        sair = QPushButton("Sair")
        sair.setObjectName("Nav")
        sair.setCursor(Qt.PointingHandCursor)
        sair.setMinimumHeight(40)
        sair.clicked.connect(self._sair)
        sl.addWidget(sair)

        root.addWidget(side)
        root.addWidget(self.stack, 1)
        self.setCentralWidget(central)

        if self.grupo.buttons():
            self.grupo.buttons()[0].setChecked(True)

    def _nav(self, layout, texto, factory):
        b = QPushButton(texto)
        b.setObjectName("Nav")
        b.setCheckable(True)
        b.setCursor(Qt.PointingHandCursor)
        b.setMinimumHeight(40)
        layout.addWidget(b)

        idx = self.stack.count()
        self.grupo.addButton(b, idx)
        b.clicked.connect(lambda _, i=idx: self.stack.setCurrentIndex(i))
        self.stack.addWidget(factory())

    def _sair(self):
        if QMessageBox.question(self, "Sair", "Deseja sair?") == QMessageBox.Yes:
            self.saiu.emit()
            self.close()