from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget,
    QTableWidget, QHeaderView, QSizePolicy,
)
from config import (
    C, EMOJI_CATEGORIA, EMOJI_PRODUTO, COR_CATEGORIA,
)


def moeda(v):
    return "R$ " + f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def hora(s):
    try:
        return s[11:16]
    except Exception:
        return ""


def data_br(s):
    try:
        return f"{s[8:10]}/{s[5:7]}/{s[0:4]} {s[11:16]}"
    except Exception:
        return s or ""


def tabela(headers, stretch=0):
    t = QTableWidget()
    t.setColumnCount(len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.verticalHeader().setVisible(False)
    t.setEditTriggers(QTableWidget.NoEditTriggers)
    t.setSelectionBehavior(QTableWidget.SelectRows)
    t.setAlternatingRowColors(False)
    t.setShowGrid(True)
    if stretch is not None:
        t.horizontalHeader().setSectionResizeMode(stretch, QHeaderView.Stretch)
    return t


class StatCard(QFrame):
    def __init__(self, label, valor, cor=C.PRIMARY):
        super().__init__()
        self.setObjectName("Card")
        self.setMinimumHeight(105)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        l = QVBoxLayout(self)
        l.setContentsMargins(20, 18, 20, 18)
        l.setSpacing(6)

        v = QLabel(str(valor))
        v.setStyleSheet(f"font-size: 26px; font-weight: 700; color: {cor};")
        l.addWidget(v)

        t = QLabel(label)
        t.setStyleSheet(f"color: {C.MUTED}; font-size: 11px; font-weight: 600;")
        l.addWidget(t)


class ProdutoCard(QFrame):
    clicado = Signal(dict)

    def __init__(self, produto):
        super().__init__()
        self.produto = dict(produto)
        self.setObjectName("ProdutoCard")
        self.setFixedSize(200, 215)
        self.setCursor(Qt.PointingHandCursor)

        cat = self.produto["categoria"]
        emoji_txt = EMOJI_PRODUTO.get(self.produto["nome"], EMOJI_CATEGORIA.get(cat, "🍽️"))
        cor_bg = COR_CATEGORIA.get(cat, "#F1F5F9")

        l = QVBoxLayout(self)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(0)

        banner = QFrame()
        banner.setFixedHeight(90)
        banner.setStyleSheet(f"""
            QFrame {{
                background: {cor_bg};
                border-top-left-radius: 12px;
                border-top-right-radius: 12px;
            }}
        """)
        bl = QVBoxLayout(banner)
        bl.setContentsMargins(0, 0, 0, 0)

        emoji = QLabel(emoji_txt)
        emoji.setAlignment(Qt.AlignCenter)
        emoji.setStyleSheet("font-size: 46px; background: transparent;")
        bl.addWidget(emoji)
        l.addWidget(banner)

        content = QWidget()
        content.setStyleSheet(f"""
            QWidget {{
                background: {C.CARD};
                border-bottom-left-radius: 12px;
                border-bottom-right-radius: 12px;
                border: 1px solid {C.BORDER};
                border-top: none;
            }}
        """)
        cl = QVBoxLayout(content)
        cl.setContentsMargins(14, 10, 14, 12)
        cl.setSpacing(4)

        top = QHBoxLayout()
        cat_lbl = QLabel(cat.upper())
        cat_lbl.setStyleSheet(f"""
            color: {C.MUTED}; font-size: 9px; font-weight: 700;
            letter-spacing: 0.5px;
        """)
        top.addWidget(cat_lbl)
        top.addStretch()

        if self.produto["estoque"] <= 5:
            tag = QLabel("últimas")
            tag.setStyleSheet(f"""
                background: {C.DANGER_LIGHT}; color: {C.DANGER};
                border-radius: 6px; padding: 1px 6px;
                font-size: 9px; font-weight: 700;
            """)
            top.addWidget(tag)
        cl.addLayout(top)

        nome = QLabel(self.produto["nome"])
        nome.setStyleSheet("font-size: 13px; font-weight: 600;")
        nome.setWordWrap(True)
        nome.setMinimumHeight(34)
        cl.addWidget(nome)

        cl.addStretch()

        preco = QLabel(moeda(self.produto["preco"]))
        preco.setStyleSheet(f"color: {C.PRIMARY}; font-size: 16px; font-weight: 700;")
        cl.addWidget(preco)

        est = QLabel(f"{self.produto['estoque']} em estoque")
        est.setStyleSheet(f"color: {C.MUTED}; font-size: 10px;")
        cl.addWidget(est)

        l.addWidget(content)

    def mousePressEvent(self, e):
        self.clicado.emit(self.produto)


class ItemCarrinho(QFrame):
    mais = Signal(int)
    menos = Signal(int)
    remover = Signal(int)

    def __init__(self, produto, qtd):
        super().__init__()
        self.pid = produto["id"]
        self.setStyleSheet(f"""
            QFrame {{ background: {C.CARD}; border: 1px solid {C.BORDER}; border-radius: 10px; }}
        """)
        l = QHBoxLayout(self)
        l.setContentsMargins(12, 10, 12, 10)
        l.setSpacing(8)

        info = QVBoxLayout()
        info.setSpacing(2)
        nome = QLabel(produto["nome"])
        nome.setStyleSheet("font-weight: 600; font-size: 13px;")
        nome.setWordWrap(True)
        preco = QLabel(moeda(produto["preco"]))
        preco.setStyleSheet(f"color: {C.MUTED}; font-size: 11px;")
        info.addWidget(nome)
        info.addWidget(preco)
        l.addLayout(info, 1)

        def btn(txt, cb, primary=False):
            b = QPushButton(txt)
            b.setFixedSize(28, 28)
            b.setCursor(Qt.PointingHandCursor)
            bg = C.PRIMARY if primary else C.CARD
            cor = "white" if primary else C.TEXT
            b.setStyleSheet(f"""
                QPushButton {{
                    background: {bg}; color: {cor}; border: 1px solid {C.BORDER};
                    border-radius: 6px; font-weight: 700; font-size: 14px; padding: 0;
                }}
                QPushButton:hover {{ background: {C.PRIMARY_LIGHT}; border-color: {C.PRIMARY}; }}
            """)
            b.clicked.connect(cb)
            return b

        l.addWidget(btn("−", lambda: self.menos.emit(self.pid)))
        q = QLabel(str(qtd))
        q.setFixedWidth(28)
        q.setAlignment(Qt.AlignCenter)
        q.setStyleSheet("font-weight: 700;")
        l.addWidget(q)
        l.addWidget(btn("+", lambda: self.mais.emit(self.pid), True))

        sub = QLabel(moeda(produto["preco"] * qtd))
        sub.setFixedWidth(80)
        sub.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        sub.setStyleSheet("font-weight: 700;")
        l.addWidget(sub)

        r = QPushButton("x")
        r.setFixedSize(24, 24)
        r.setCursor(Qt.PointingHandCursor)
        r.setStyleSheet(f"""
            QPushButton {{
                background: transparent; color: {C.MUTED};
                border: none; font-weight: 700; padding: 0;
            }}
            QPushButton:hover {{ color: {C.DANGER}; }}
        """)
        r.clicked.connect(lambda: self.remover.emit(self.pid))
        l.addWidget(r)


class PedidoCard(QFrame):
    acao = Signal(int, str)
    cancelar = Signal(int)

    def __init__(self, pedido, itens, cor_borda=C.PRIMARY):
        super().__init__()
        self.setStyleSheet(f"""
            QFrame {{
                background: {C.CARD}; border: 1px solid {C.BORDER};
                border-left: 4px solid {cor_borda}; border-radius: 10px;
            }}
        """)
        l = QVBoxLayout(self)
        l.setContentsMargins(14, 12, 14, 12)
        l.setSpacing(6)

        top = QHBoxLayout()
        cod = QLabel(pedido["codigo"])
        cod.setStyleSheet("font-size: 16px; font-weight: 700;")
        top.addWidget(cod)
        top.addStretch()
        h = QLabel(hora(pedido["criado_em"]))
        h.setStyleSheet(f"color: {C.MUTED}; font-size: 11px;")
        top.addWidget(h)

        x = QPushButton("✕")
        x.setFixedSize(24, 24)
        x.setCursor(Qt.PointingHandCursor)
        x.setToolTip("Cancelar pedido")
        x.setStyleSheet(f"""
            QPushButton {{
                background: transparent; color: {C.MUTED};
                border: none; font-weight: 700; font-size: 13px; padding: 0;
            }}
            QPushButton:hover {{
                background: {C.DANGER_LIGHT}; color: {C.DANGER};
                border-radius: 6px;
            }}
        """)
        x.clicked.connect(lambda: self.cancelar.emit(pedido["id"]))
        top.addWidget(x)

        l.addLayout(top)

        cli = QLabel(pedido["cliente_nome"])
        cli.setStyleSheet(f"color: {C.PRIMARY}; font-size: 13px; font-weight: 600;")
        l.addWidget(cli)

        for it in itens:
            il = QLabel(f"{it['quantidade']}x  {it['produto_nome']}")
            il.setStyleSheet(f"color: {C.MUTED}; font-size: 12px;")
            il.setWordWrap(True)
            l.addWidget(il)

        l.addSpacing(4)

        bot = QHBoxLayout()
        tot = QLabel(moeda(pedido["total"]))
        tot.setStyleSheet("font-weight: 700;")
        bot.addWidget(tot)
        bot.addStretch()

        st = pedido["status"]
        if st == "aguardando":
            b = QPushButton("Preparar")
            b.setProperty("variant", "warning")
            b.clicked.connect(lambda: self.acao.emit(pedido["id"], "preparando"))
            bot.addWidget(b)
        elif st == "preparando":
            b = QPushButton("Pronto")
            b.setProperty("variant", "success")
            b.clicked.connect(lambda: self.acao.emit(pedido["id"], "pronto"))
            bot.addWidget(b)
        elif st == "pronto":
            b = QPushButton("Entregar")
            b.clicked.connect(lambda: self.acao.emit(pedido["id"], "entregue"))
            bot.addWidget(b)
        l.addLayout(bot)