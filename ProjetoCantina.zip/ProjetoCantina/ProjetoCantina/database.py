import sqlite3
import hashlib
from datetime import datetime
from config import DB

_conn = None


def conn():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(DB)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA foreign_keys = ON")
    return _conn


def _hash(s):
    return hashlib.sha256(s.encode()).hexdigest()


def init():
    c = conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        senha_hash TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        descricao TEXT DEFAULT '',
        preco REAL NOT NULL,
        categoria TEXT NOT NULL,
        estoque INTEGER NOT NULL DEFAULT 0,
        ativo INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT UNIQUE NOT NULL,
        cliente_nome TEXT NOT NULL,
        total REAL NOT NULL,
        forma_pagamento TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'aguardando',
        criado_em TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS itens_pedido (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pedido_id INTEGER NOT NULL,
        produto_id INTEGER NOT NULL,
        quantidade INTEGER NOT NULL,
        preco_unitario REAL NOT NULL,
        subtotal REAL NOT NULL,
        FOREIGN KEY(pedido_id) REFERENCES pedidos(id),
        FOREIGN KEY(produto_id) REFERENCES produtos(id)
    );

    CREATE TABLE IF NOT EXISTS despesas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao TEXT NOT NULL,
        valor REAL NOT NULL,
        data TEXT NOT NULL
    );
    """)

    if c.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
        c.executemany(
            "INSERT INTO usuarios (nome, username, senha_hash) VALUES (?,?,?)",
            [
                ("Administrador", "admin", _hash("admin")),
                ("Operador", "op", _hash("123")),
            ],
        )

    _seed_produtos(c)
    c.commit()


_PRODUTOS = [
    ("Doce", "", 3.00, "Doces", 30),
    ("Paçoca", "", 1.00, "Doces", 50),
    ("Bom Bom", "", 2.50, "Doces", 40),
    ("Trento", "", 4.50, "Doces", 30),
    ("Biscoito", "", 3.50, "Doces", 30),
    ("Emília", "", 2.50, "Doces", 30),
    ("Halls", "", 2.50, "Doces", 40),
    ("Bolo", "Fatia", 6.00, "Doces", 15),
    ("Suspiro", "", 3.00, "Doces", 20),
    ("Pão de Mel", "", 5.00, "Doces", 20),
    ("Copinho de Banana", "", 3.00, "Doces", 20),
    ("Cocada", "", 3.00, "Doces", 20),
    ("Doce em Massa de Batata Doce", "", 3.00, "Doces", 20),
    ("Cajuzinho", "", 3.00, "Doces", 20),
    ("Geladão", "", 7.00, "Doces", 15),
    ("Cremosinho", "", 2.50, "Doces", 25),
    ("Maria Bolacha", "", 3.00, "Doces", 30),
    ("Café", "Café passado", 2.00, "Bebidas", 50),

    ("Cup Noodles", "", 7.00, "Salgados", 15),
    ("Croissant Apresuntado e Queijo", "", 7.00, "Salgados", 12),
    ("Risole de 4 Queijos", "", 5.50, "Salgados", 20),
    ("Risole de Carne", "", 5.50, "Salgados", 20),
    ("Croissant 3 Queijos", "", 6.50, "Salgados", 12),
    ("Hambúrguer com Cheddar", "", 7.00, "Salgados", 12),
    ("Enroladinho de Bauru", "", 7.00, "Salgados", 15),
    ("Pão de Batata com Calabresa", "", 6.50, "Salgados", 15),
    ("Pão de Batata de Frango", "", 6.50, "Salgados", 15),
    ("Esfiha de Carne", "", 7.00, "Salgados", 20),
    ("Coxinha", "Frango desfiado", 5.50, "Salgados", 30),
    ("Pão de Queijo", "Mineiro", 3.50, "Salgados", 40),
    ("Caldo", "Mandioca, abóbora, verde ou feijão", 20.00, "Salgados", 8),
    ("Espeto", "Carne, medalhão ou coração (quarta)", 9.00, "Salgados", 10),

    ("Guaraná 350ml", "", 5.50, "Bebidas", 30),
    ("Fanta Uva 350ml", "", 5.50, "Bebidas", 25),
    ("Fanta Laranja 350ml", "", 5.50, "Bebidas", 25),
    ("Coca-Cola Zero 350ml", "", 5.50, "Bebidas", 25),
    ("Coca-Cola 350ml", "", 5.50, "Bebidas", 30),
    ("Suco Tropical 480ml", "Uva, manga, abacaxi, açaí ou goiaba", 8.00, "Bebidas", 20),
    ("Suco Kmais 300ml", "Goiaba, laranja, uva ou maracujá", 7.50, "Bebidas", 20),
    ("Refrigerante Caçula 200ml", "Coca, Pepsi, Fanta uva ou Coca zero", 3.50, "Bebidas", 40),
]


def _seed_produtos(c):
    for nome, desc, preco, cat, est in _PRODUTOS:
        if not c.execute("SELECT 1 FROM produtos WHERE nome=?", (nome,)).fetchone():
            c.execute(
                "INSERT INTO produtos (nome, descricao, preco, categoria, estoque) VALUES (?,?,?,?,?)",
                (nome, desc, preco, cat, est),
            )


def login(user, senha):
    r = conn().execute("SELECT * FROM usuarios WHERE username=?", (user,)).fetchone()
    if r and r["senha_hash"] == _hash(senha):
        return dict(r)
    return None


def listar_produtos(busca="", categoria=None, disponiveis=False):
    sql = "SELECT * FROM produtos WHERE 1=1"
    p = []
    if busca:
        sql += " AND nome LIKE ?"
        p.append(f"%{busca}%")
    if categoria:
        sql += " AND categoria=?"
        p.append(categoria)
    if disponiveis:
        sql += " AND ativo=1 AND estoque>0"
    sql += " ORDER BY ativo DESC, nome"
    return conn().execute(sql, p).fetchall()


def obter_produto(pid):
    return conn().execute("SELECT * FROM produtos WHERE id=?", (pid,)).fetchone()


def salvar_produto(pid, nome, descricao, preco, categoria, estoque, ativo):
    c = conn()
    try:
        if pid:
            c.execute(
                """UPDATE produtos SET nome=?, descricao=?, preco=?, categoria=?,
                   estoque=?, ativo=? WHERE id=?""",
                (nome, descricao, preco, categoria, estoque, int(ativo), pid),
            )
        else:
            c.execute(
                """INSERT INTO produtos (nome, descricao, preco, categoria, estoque, ativo)
                   VALUES (?,?,?,?,?,?)""",
                (nome, descricao, preco, categoria, estoque, int(ativo)),
            )
        c.commit()
        return True, "Salvo"
    except Exception as e:
        return False, str(e)


def excluir_produto(pid):
    c = conn()
    try:
        c.execute("DELETE FROM produtos WHERE id=?", (pid,))
        c.commit()
        return True, "Excluído"
    except Exception:
        return False, "Produto já usado em pedidos. Desative ao invés de excluir."


def novo_pedido(carrinho, nome, forma):
    if not nome.strip():
        return False, "Informe o nome do cliente."
    if not carrinho:
        return False, "Carrinho vazio."

    c = conn()
    for item in carrinho.values():
        p = c.execute("SELECT nome, estoque FROM produtos WHERE id=?",
                      (item["produto"]["id"],)).fetchone()
        if not p or p["estoque"] < item["qtd"]:
            return False, f"Sem estoque suficiente: {p['nome'] if p else 'item'}"

    try:
        ult = c.execute("SELECT codigo FROM pedidos ORDER BY id DESC LIMIT 1").fetchone()
        n = 1
        if ult:
            try:
                n = int(ult["codigo"].split("-")[1]) + 1
            except Exception:
                pass
        codigo = f"A-{n:03d}"
        total = sum(i["produto"]["preco"] * i["qtd"] for i in carrinho.values())

        cur = c.execute(
            """INSERT INTO pedidos (codigo, cliente_nome, total, forma_pagamento, status)
               VALUES (?,?,?,?,?)""",
            (codigo, nome.strip(), total, forma, "aguardando"),
        )
        pid = cur.lastrowid

        for i in carrinho.values():
            p, q = i["produto"], i["qtd"]
            c.execute(
                """INSERT INTO itens_pedido
                   (pedido_id, produto_id, quantidade, preco_unitario, subtotal)
                   VALUES (?,?,?,?,?)""",
                (pid, p["id"], q, p["preco"], p["preco"] * q),
            )
            c.execute("UPDATE produtos SET estoque = estoque - ? WHERE id=?", (q, p["id"]))

        c.commit()
        return True, {"id": pid, "codigo": codigo, "total": total}
    except Exception as e:
        c.rollback()
        return False, str(e)


def listar_pedidos(status=None, data_ini=None, data_fim=None):
    sql = "SELECT * FROM pedidos WHERE 1=1"
    p = []
    if status:
        sql += " AND status=?"
        p.append(status)
    if data_ini:
        sql += " AND DATE(criado_em)>=DATE(?)"
        p.append(data_ini)
    if data_fim:
        sql += " AND DATE(criado_em)<=DATE(?)"
        p.append(data_fim)
    sql += " ORDER BY criado_em DESC LIMIT 300"
    return conn().execute(sql, p).fetchall()


def obter_pedido(pid):
    c = conn()
    p = c.execute("SELECT * FROM pedidos WHERE id=?", (pid,)).fetchone()
    if not p:
        return None, []
    itens = c.execute(
        """SELECT i.*, pr.nome AS produto_nome
           FROM itens_pedido i
           LEFT JOIN produtos pr ON pr.id = i.produto_id
           WHERE i.pedido_id=?""",
        (pid,),
    ).fetchall()
    return p, itens


def mudar_status(pid, status):
    c = conn()
    c.execute("UPDATE pedidos SET status=? WHERE id=?", (status, pid))
    c.commit()


def cancelar_pedido(pid):
    c = conn()
    p = c.execute("SELECT * FROM pedidos WHERE id=? AND status!='cancelado'", (pid,)).fetchone()
    if not p:
        return False, "Pedido já cancelado."
    for it in c.execute("SELECT * FROM itens_pedido WHERE pedido_id=?", (pid,)).fetchall():
        c.execute("UPDATE produtos SET estoque = estoque + ? WHERE id=?",
                  (it["quantidade"], it["produto_id"]))
    c.execute("UPDATE pedidos SET status='cancelado' WHERE id=?", (pid,))
    c.commit()
    return True, "Cancelado"


def criar_despesa(descricao, valor, data):
    c = conn()
    c.execute("INSERT INTO despesas (descricao, valor, data) VALUES (?,?,?)",
              (descricao, valor, data))
    c.commit()


def listar_despesas(ini=None, fim=None):
    sql = "SELECT * FROM despesas WHERE 1=1"
    p = []
    if ini:
        sql += " AND data>=?"
        p.append(ini)
    if fim:
        sql += " AND data<=?"
        p.append(fim)
    sql += " ORDER BY data DESC, id DESC LIMIT 200"
    return conn().execute(sql, p).fetchall()


def excluir_despesa(did):
    c = conn()
    c.execute("DELETE FROM despesas WHERE id=?", (did,))
    c.commit()


def resumo_dia():
    hoje = datetime.now().strftime("%Y-%m-%d")
    c = conn()
    p = c.execute(
        """SELECT COUNT(*) AS qtd, COALESCE(SUM(total),0) AS fat
           FROM pedidos WHERE DATE(criado_em)=DATE(?) AND status!='cancelado'""",
        (hoje,),
    ).fetchone()
    d = c.execute("SELECT COALESCE(SUM(valor),0) AS tot FROM despesas WHERE data=?",
                  (hoje,)).fetchone()
    return {
        "qtd": p["qtd"],
        "faturamento": p["fat"],
        "despesas": d["tot"],
        "lucro": p["fat"] - d["tot"],
    }


def top_produtos(limite=8):
    return conn().execute(
        """SELECT pr.nome, SUM(i.quantidade) AS qtd, SUM(i.subtotal) AS total
           FROM itens_pedido i
           JOIN produtos pr ON pr.id = i.produto_id
           JOIN pedidos p ON p.id = i.pedido_id
           WHERE p.status != 'cancelado'
           GROUP BY pr.id ORDER BY qtd DESC LIMIT ?""",
        (limite,),
    ).fetchall()


def por_forma(ini=None, fim=None):
    sql = """SELECT forma_pagamento, COUNT(*) AS qtd, SUM(total) AS total
             FROM pedidos WHERE status != 'cancelado'"""
    p = []
    if ini:
        sql += " AND DATE(criado_em)>=DATE(?)"
        p.append(ini)
    if fim:
        sql += " AND DATE(criado_em)<=DATE(?)"
        p.append(fim)
    sql += " GROUP BY forma_pagamento ORDER BY total DESC"
    return conn().execute(sql, p).fetchall()


def total_despesas(ini=None, fim=None):
    sql = "SELECT COALESCE(SUM(valor),0) AS t FROM despesas WHERE 1=1"
    p = []
    if ini:
        sql += " AND data>=?"
        p.append(ini)
    if fim:
        sql += " AND data<=?"
        p.append(fim)
    return conn().execute(sql, p).fetchone()["t"]