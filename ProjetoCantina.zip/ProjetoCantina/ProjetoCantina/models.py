class Carrinho:
    """Carrinho simples em memória. Chave = id do produto."""

    def __init__(self):
        self.itens = {}  

    def adicionar(self, produto):
        pid = produto["id"]
        if pid in self.itens:
            self.itens[pid]["qtd"] += 1
        else:
            self.itens[pid] = {"produto": dict(produto), "qtd": 1}

    def aumentar(self, pid):
        if pid in self.itens:
            self.itens[pid]["qtd"] += 1

    def diminuir(self, pid):
        if pid not in self.itens:
            return
        self.itens[pid]["qtd"] -= 1
        if self.itens[pid]["qtd"] <= 0:
            del self.itens[pid]

    def remover(self, pid):
        self.itens.pop(pid, None)

    def total(self):
        return sum(i["produto"]["preco"] * i["qtd"] for i in self.itens.values())

    def quantidade(self):
        return sum(i["qtd"] for i in self.itens.values())

    def vazio(self):
        return len(self.itens) == 0

    def limpar(self):
        self.itens.clear()