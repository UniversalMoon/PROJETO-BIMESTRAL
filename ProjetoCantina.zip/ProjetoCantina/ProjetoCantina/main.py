import sys
from PySide6.QtWidgets import QApplication
from styles import QSS
from database import init
from login import Login
from janela import Janela


class App:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setStyleSheet(QSS)
        self.login = None
        self.janela = None

    def rodar(self):
        self._login()
        sys.exit(self.app.exec())

    def _login(self):
        self.login = Login()
        self.login.entrou.connect(self._logar)
        self.login.show()

    def _logar(self, usuario):
        self.login.close()
        self.janela = Janela(usuario)
        self.janela.saiu.connect(self._deslogar)
        self.janela.showMaximized()

    def _deslogar(self):
        self.janela.close()
        self.janela = None
        self._login()


if __name__ == "__main__":
    init()
    App().rodar()