from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QMessageBox,
)
from config import APP, C
from database import login as db_login


class Login(QWidget):
    entrou = Signal(dict)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP + " — Entrar")
        self.resize(900, 600)

        root = QVBoxLayout(self)
        root.setAlignment(Qt.AlignCenter)

        box = QFrame()
        box.setFixedWidth(380)
        box.setStyleSheet("QFrame { background: white; border-radius: 16px; }")
        b = QVBoxLayout(box)
        b.setContentsMargins(36, 36, 36, 36)
        b.setSpacing(10)

        t = QLabel(APP)
        t.setAlignment(Qt.AlignCenter)
        t.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {C.TEXT};")
        b.addWidget(t)

        s = QLabel("Acesse com seu usuário")
        s.setAlignment(Qt.AlignCenter)
        s.setStyleSheet(f"color: {C.MUTED}; font-size: 12px; margin-bottom: 10px;")
        b.addWidget(s)

        self.user = QLineEdit()
        self.user.setPlaceholderText("Usuário")
        self.user.setMinimumHeight(40)
        b.addWidget(self.user)

        self.pwd = QLineEdit()
        self.pwd.setPlaceholderText("Senha")
        self.pwd.setEchoMode(QLineEdit.Password)
        self.pwd.setMinimumHeight(40)
        b.addWidget(self.pwd)

        btn = QPushButton("Entrar")
        btn.setMinimumHeight(42)
        btn.clicked.connect(self._entrar)
        b.addWidget(btn)

        hint = QLabel("admin / admin")
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet(f"color: {C.MUTED}; font-size: 11px; margin-top: 6px;")
        b.addWidget(hint)

        root.addWidget(box)

        self.user.returnPressed.connect(self._entrar)
        self.pwd.returnPressed.connect(self._entrar)
        self.user.setFocus()

    def _entrar(self):
        u = self.user.text().strip()
        p = self.pwd.text()
        if not u or not p:
            QMessageBox.warning(self, "Aviso", "Preencha usuário e senha.")
            return
        user = db_login(u, p)
        if not user:
            QMessageBox.critical(self, "Falha", "Usuário ou senha inválidos.")
            self.pwd.clear()
            return
        self.entrou.emit(user)